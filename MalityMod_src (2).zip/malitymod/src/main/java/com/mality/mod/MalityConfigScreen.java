package com.mality.mod;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Checkbox;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Style;
import net.minecraft.util.FormattedCharSequence;

/** Mods > Mality > Config: API anahtarı, model ve "mality de" kutusu. */
public class MalityConfigScreen extends Screen {
    private final Screen parent;
    private EditBox keyBox;
    private EditBox modelBox;
    private EditBox fishKeyBox;
    private EditBox fishModelBox;
    private Checkbox requireBox;

    public MalityConfigScreen(Screen parent) {
        super(Component.translatable("malitymod.config.title"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int cx = this.width / 2;

        int x = cx - 150;
        keyBox = new EditBox(this.font, x, 52, 300, 20, Component.translatable("malitymod.config.key"));
        keyBox.setMaxLength(256);
        keyBox.setValue(Config.GROQ_API_KEY.get());
        keyBox.setFormatter((text, offset) -> FormattedCharSequence.forward("*".repeat(text.length()), Style.EMPTY));
        this.addRenderableWidget(keyBox);

        modelBox = new EditBox(this.font, x, 92, 300, 20, Component.translatable("malitymod.config.model"));
        modelBox.setMaxLength(100);
        modelBox.setValue(Config.GROQ_MODEL.get());
        this.addRenderableWidget(modelBox);

        fishKeyBox = new EditBox(this.font, x, 132, 300, 20, Component.translatable("malitymod.config.fishkey"));
        fishKeyBox.setMaxLength(256);
        fishKeyBox.setValue(Config.FISH_API_KEY.get());
        fishKeyBox.setFormatter((text, offset) -> FormattedCharSequence.forward("*".repeat(text.length()), Style.EMPTY));
        this.addRenderableWidget(fishKeyBox);

        fishModelBox = new EditBox(this.font, x, 172, 300, 20, Component.translatable("malitymod.config.fishmodel"));
        fishModelBox.setMaxLength(100);
        fishModelBox.setValue(Config.FISH_MODEL.get());
        this.addRenderableWidget(fishModelBox);

        requireBox = new Checkbox(x, 202, 300, 20,
                Component.translatable("malitymod.config.require"), Config.REQUIRE_MALITY.get());
        this.addRenderableWidget(requireBox);

        this.addRenderableWidget(Button.builder(CommonComponents.GUI_DONE, b -> {
            Config.GROQ_API_KEY.set(keyBox.getValue().trim());
            Config.GROQ_MODEL.set(modelBox.getValue().trim().isEmpty() ? "openai/gpt-oss-20b" : modelBox.getValue().trim());
            Config.FISH_API_KEY.set(fishKeyBox.getValue().trim());
            Config.FISH_MODEL.set(fishModelBox.getValue().trim());
            Config.REQUIRE_MALITY.set(requireBox.selected());
            Config.GROQ_API_KEY.save();
            this.minecraft.setScreen(parent);
        }).bounds(cx - 100, this.height - 40, 200, 20).build());
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        this.renderBackground(g);
        g.drawCenteredString(this.font, this.title, this.width / 2, 15, 0xFFFFFF);
        g.drawString(this.font, Component.translatable("malitymod.config.key"), this.width / 2 - 150, 42, 0xA0A0A0);
        g.drawString(this.font, Component.translatable("malitymod.config.model"), this.width / 2 - 150, 82, 0xA0A0A0);
        g.drawString(this.font, Component.translatable("malitymod.config.fishkey"), this.width / 2 - 150, 122, 0xA0A0A0);
        g.drawString(this.font, Component.translatable("malitymod.config.fishmodel"), this.width / 2 - 150, 162, 0xA0A0A0);
        super.render(g, mouseX, mouseY, partial);
    }

    @Override
    public void onClose() {
        this.minecraft.setScreen(parent);
    }
}
